import React from 'react';
import { X } from 'lucide-react';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { useChatStore } from './store/chatStore';
import { Logo } from './components/Logo';
import { Footer } from './components/Footer';
import './styles/fonts.css';

export const App: React.FC = () => {
  const { messages, addMessage, clearMessages } = useChatStore();

  const handleSendMessage = (content: string) => {
    addMessage({ content, sender: 'user' });

    setTimeout(() => {
      addMessage({
        content: "I'm here to help you find the perfect product! What are you looking for today?",
        sender: 'bot',
      });
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-custom">
      <div className="container mx-auto max-w-4xl px-4 py-8">
        <div className="rounded-lg bg-background-light shadow-2xl border border-border-light">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-border-main px-6 py-4">
            <Logo />
            <button
              onClick={clearMessages}
              className="rounded-full p-2 text-primary-text/70 hover:bg-primary-light/10 
                       transition-colors duration-200"
            >
              <X size={20} />
            </button>
          </div>

          {/* Chat Messages */}
          <div className="h-[500px] overflow-y-auto p-6 space-y-4 bg-background-main">
            {messages.length === 0 ? (
              <div className="flex h-full items-center justify-center text-primary-text/50">
                Start a conversation!
              </div>
            ) : (
              messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))
            )}
          </div>

          {/* Input */}
          <div className="border-t border-border-main p-6 bg-background-light">
            <ChatInput onSend={handleSendMessage} />
          </div>

          {/* Footer */}
          <Footer />
        </div>
      </div>
    </div>
  );
}

export default App;