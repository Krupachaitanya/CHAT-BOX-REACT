import { useState, useCallback } from 'react';
import { useChatStore } from '../store/chatStore';
import { generateBotResponse } from '../utils/chatUtils';

export const useChat = () => {
  const [isTyping, setIsTyping] = useState(false);
  const { addMessage } = useChatStore();

  const sendMessage = useCallback((content: string) => {
    // Add user message
    addMessage({ content, sender: 'user' });

    // Simulate bot typing
    setIsTyping(true);
    
    setTimeout(() => {
      const botResponse = generateBotResponse(content);
      addMessage({ content: botResponse, sender: 'bot' });
      setIsTyping(false);
    }, 1000);
  }, [addMessage]);

  return {
    isTyping,
    sendMessage,
  };
};