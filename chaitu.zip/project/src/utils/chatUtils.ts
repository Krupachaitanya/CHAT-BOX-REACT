import { Message } from '../types';

export const formatChatResponse = (content: string): Omit<Message, 'id' | 'timestamp'> => ({
  content,
  sender: 'bot',
});

export const generateBotResponse = (userMessage: string) => {
  // TODO: Implement actual bot logic
  return "I'm here to help you find the perfect product! What are you looking for today?";
};