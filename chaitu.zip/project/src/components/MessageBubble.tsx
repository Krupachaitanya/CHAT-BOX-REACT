import React from 'react';

interface MessageBubbleProps {
  isBot: boolean;
  content: string;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ isBot, content }) => {
  return (
    <div
      className={`rounded-lg px-4 py-2 ${
        isBot
          ? 'bg-accent-dark/20 text-primary-text border border-accent-dark/20'
          : 'bg-primary-light/10 text-primary-text border border-primary-light/10'
      }`}
    >
      {content}
    </div>
  );
};