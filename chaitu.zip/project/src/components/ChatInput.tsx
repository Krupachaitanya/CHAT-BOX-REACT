import React, { useState } from 'react';
import { Send } from 'lucide-react';

interface ChatInputProps {
  onSend: (message: string) => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({ onSend }) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSend(message.trim());
      setMessage('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your message..."
        className="flex-1 rounded-lg border border-border-light bg-background-main px-4 py-2 
                 text-primary-text placeholder-primary-text/40
                 focus:outline-none focus:ring-2 focus:ring-accent-main focus:border-accent-main
                 transition-colors duration-200"
      />
      <button
        type="submit"
        className="rounded-lg bg-accent-main px-4 py-2 text-primary-text 
                 hover:bg-accent-dark focus:outline-none focus:ring-2 
                 focus:ring-accent-main focus:ring-offset-2 focus:ring-offset-background-light
                 transition-colors duration-200"
      >
        <Send size={20} />
      </button>
    </form>
  );
};