import React from 'react';
import { MessageSquare } from 'lucide-react';

export const Logo: React.FC = () => {
  return (
    <div className="flex items-center gap-2">
      <MessageSquare className="text-accent-main" size={28} />
      <h1 className="font-belgeri text-3xl font-bold bg-gradient-to-r from-primary-dark to-accent-main 
                     text-transparent bg-clip-text">
        SHEMU
      </h1>
    </div>
  );
};