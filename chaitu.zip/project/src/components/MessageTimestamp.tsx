import React from 'react';
import { format } from 'date-fns';

interface MessageTimestampProps {
  timestamp: Date;
}

export const MessageTimestamp: React.FC<MessageTimestampProps> = ({ timestamp }) => {
  return (
    <span className="text-xs text-primary-dark/60 mt-1">
      {format(timestamp, 'HH:mm')}
    </span>
  );
};