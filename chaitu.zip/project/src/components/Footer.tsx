import React from 'react';

export const Footer: React.FC = () => {
  return (
    <div className="text-center py-4 text-sm text-primary-text/60 border-t border-border-main
                    bg-background-light">
      <p className="font-medium">
        © 2024 All Rights Reserved to{' '}
        <span className="text-accent-light font-bold">SHEMU</span>
      </p>
    </div>
  );
};