import React from 'react';
import { Bot, User } from 'lucide-react';

interface MessageAvatarProps {
  isBot: boolean;
}

export const MessageAvatar: React.FC<MessageAvatarProps> = ({ isBot }) => {
  return (
    <div
      className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center
        ${
          isBot
            ? 'bg-accent-dark/20 text-accent-light border border-accent-dark/30'
            : 'bg-primary-light/10 text-primary-text/70 border border-primary-light/20'
        }`}
    >
      {isBot ? <Bot size={20} /> : <User size={20} />}
    </div>
  );
};